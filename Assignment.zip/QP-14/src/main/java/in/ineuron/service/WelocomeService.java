package in.ineuron.service;

public class WelocomeService {
	
	
	public String getWelcomeMeessage(String name) {
		return "Welcome to our page "+name;
		
	}

}
