package in.ineuron.service;

public class ExceptionService{
	
	


	public String checkNegativeNumberOrNot(int number) {
		

       int[] arr = new int[number];
		
	   return "Size of the Array is ::"+arr.length;
		
	}

}
