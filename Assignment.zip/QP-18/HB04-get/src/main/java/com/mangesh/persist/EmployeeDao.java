package com.mangesh.persist;

import com.mangesh.model.Employee;

public interface EmployeeDao {

	public Employee getEmployee(int id);
	
	
}
