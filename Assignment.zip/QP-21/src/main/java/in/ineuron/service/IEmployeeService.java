package in.ineuron.service;

import in.ineuron.model.Employee;

public interface IEmployeeService {

	public Integer registerEmployee(Employee employee);
	
}
